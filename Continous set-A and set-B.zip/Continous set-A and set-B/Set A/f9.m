function [out]=f11(x)
    out=sum(x.^2);
end