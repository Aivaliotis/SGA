close all
clear all

% mex cec17_func.cpp -DWINDOWS

kappa=0;

params.ShowIterInfo = 0; % Flag for Showing Iteration Information
params.Showinter=0;
params.SelMethod = 1;       % Breeding Method
params.CrossMethod = 1;     % Cross Breeding Method
params.randdim = 50;
params.VelCoe = 0.5;

params.exenum = 100;
problem.nVar = 50;   % Number of Variables 

 Call_PSO
 Call_GA
 Call_SGA
 Call_PGPHEA
 Call_HPSOM

createplot